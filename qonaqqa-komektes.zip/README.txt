﻿Архивті ашыңыз. Ішіндегі HTML файлын браузерде іске қосыңыз.
Open the ZIP archive, then open the HTML file in a browser.
